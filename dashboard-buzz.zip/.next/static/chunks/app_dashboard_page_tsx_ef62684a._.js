(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_b1ac0bb2.js",
  "static/chunks/_bd38765a._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_6004bf20._.js",
  "static/chunks/node_modules_recharts_es6_7006a979._.js",
  "static/chunks/node_modules_@radix-ui_71f9ad84._.js",
  "static/chunks/node_modules_@supabase_2c814c41._.js",
  "static/chunks/node_modules_@floating-ui_9ec1fa39._.js",
  "static/chunks/node_modules_90c5ecc4._.js"
],
    source: "dynamic"
});
