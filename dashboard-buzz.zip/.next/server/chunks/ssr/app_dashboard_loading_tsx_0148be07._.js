module.exports = {

"[project]/app/dashboard/loading.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>Loading
});
function Loading() {
    return null;
}
}),

};

//# sourceMappingURL=app_dashboard_loading_tsx_0148be07._.js.map